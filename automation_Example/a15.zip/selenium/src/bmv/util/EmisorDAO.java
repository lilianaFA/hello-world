package bmv.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Vector;

public class EmisorDAO {

	public EmisorDAO() {
		// TODO Auto-generated constructor stub
	}



 public Vector<EmisorBean> archivo(String archivo)
	{EmisorBean eda;
	 Vector <EmisorBean> a  = new Vector<EmisorBean> ();
	 BufferedReader br;
	 String line;
	   
	    try 
	       {
	    	br = new BufferedReader(new FileReader(archivo));
	        
	        while (br.ready())  
	        {line= br.readLine().toString();
	        	eda = new EmisorBean();
	        eda.setEmisorBolsa(line.toString());
	         a.add(eda);
	        }
	        br.close();
	      } 
	    catch (Exception e){e.printStackTrace();}
		return a;
}
	
 
	public static void main(String[] args) 
	{ 
	
	
	EmisorDAO ed = new EmisorDAO();
	Vector<EmisorBean>  ve =ed.archivo("C:/wrk/juno/selenium/src/bmv/util/Emisor.txt");
		
	for (int i = 0; i<ve.size(); i++)
	{
		String a = ve.elementAt(i).getEmisorBolsa().toString();
		System.out.println(""+a);
		
	}
	}
}
