package bmv.TestCase;

import java.util.List;
import java.util.Set;
import java.util.Vector;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import Util.Launcher;

import bmv.tareas.*;
import bmv.util.*;

import bmv.objetos.Busca;

public class SeriesOperadas 
{
	static String Log = "" ;
	public SeriesOperadas() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{  General g= new General();	
	   EmisorDAO ed = new EmisorDAO();
	   //Datos
	   Vector<EmisorBean>  ve =ed.archivo("C:/wrk/juno/selenium/src/bmv/util/Emisor.txt");
		
	     //Launcher l = new Launcher();
		 WebDriver driver =  g.Firefox(); //g.IE();
				 
		 TareaInicio tar = new TareaInicio(driver);	
		 TareaBusca bus = new TareaBusca(driver); 
		 
		 tar.LaunchBMV();
		 tar.GoAcercadeBolsa();
		 tar.GoSeriesOperadas();
	 tar.Tabla();
		
/*		 
		 g.Takepicture("tabla", driver);
              
		 tar.cotiza("GBM");
		 String ventana= driver.getWindowHandle();
		 
		 g.Takepicture("cotiza", driver);
	
		 
		 try
		 {
	     Set<String> listav = driver.getWindowHandles();
	       for(String sw : listav)
	        {System.out.println(""+sw.toString());
		       if (!ventana.equals(sw))
	             { driver.switchTo().window(sw) ;
	             }		
	        }
	
	   //  bus.Emisoas("AMXL");	 
	    // GoogleSearchPage page = PageFactory.initElements(driver, GoogleSearchPage.class);
	     
	      Busca load= PageFactory.initElements(driver, Busca.class);
	   
	     load.emisor("AMXL");
	     
	     
	     for (int i = 0; i<ve.size(); i++)
			{	String a = ve.elementAt(i).getEmisorBolsa().toString();
				//System.out.println(""+a);
				//bus.SociedadesInversion(a);
				load.SociedadesInversion(a);
				g.Takepicture(a, driver);
			}
	     
		 //driver.close();
	     
		 }
		 catch (UnhandledAlertException uae)
		 { g.Takepicture("truena", driver);
			 Log+=uae.getAlertText();
			 
		 }
		
		 catch (NoSuchElementException nsee)
		 {nsee.printStackTrace(); }
		 
		 catch (StaleElementReferenceException sere)
		 {sere.printStackTrace(); } 
		 
		 
		 //cualquier ota del driver
		 catch (WebDriverException wde)
		 {wde.printStackTrace(); }
		 
		 //cualquier otra exception
		catch (Exception e)
		{}
*/		 
		 //Log=""+tar.Log + " " +bus.Log ;
	}

}
