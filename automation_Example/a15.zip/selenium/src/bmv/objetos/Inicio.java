package bmv.objetos;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import bmv.util.*;

public class Inicio 
{ WebDriver DriverW;

	
 public Inicio(WebDriver a)
  {DriverW=a; 
  
  }

/*
   <a onmouseout="MM_swapImgRestore();" 
      onmouseover="MM_swapImage('Image1','','/img-bmv/WB3/btn_menu_acerca_2.gif',1);" 
	  href="/wb3/wb/BMV/BMV_acerca_de_la_bmv"><img 
	  id="Image1" width="89" border="0" height="38" name="Image1" alt="" 
	  src="http://www.bmv.com.mx/img-bmv/WB3/btn_menu_acerca.gif
*/

/* vesion html
	  <td><a href="/wb3/wb/BMV/BMV_acerca_de_la_bmv" 
	  onMouseOver="MM_swapImage('Image1','','/img-bmv/WB3/btn_menu_acerca_2.gif',1);" 
	  onMouseOut="MM_swapImgRestore();">
	  <img src="/img-bmv/WB3/btn_menu_acerca.gif" alt="" name="Image1" 
	  width="89" height="38" border="0" id="Image1"></a></td>	  
*/
	
	
//private String TabAcercadeBolsa="http://www.bmv.com.mx/wb3/wb/BMV/BMV_acerca_de_la_bmv";	

//private String  LnMercadoC="http://www.bmv.com.mx/wb3/wb/BMV/mercado_de_capitales";

//private String  LnSeriesO ="http://www.bmv.com.mx/img-bmv/series.html";



public final String bmv= 
"http://www.bmv.com.mx/img-bmv/series.html";
//"http://www.bmv.com.mx";

 General BMV = new General();

 
 
public WebElement getTabAcercadeBolsa() 
{WebElement wea=	//BMV.fluentWait(By.linkText(TabAcercadeBolsa)
		BMV.fluentWait( By.id("Image1")
		, DriverW,30,5);

	return wea;
}

public WebElement getLnMercadoC() 
{WebElement wea=	BMV.fluentWait( 
		By.id("Image2"), DriverW,30,5);
  return wea;	
}


public WebElement getLnSeriesO() 
{ return	BMV.fluentWait( By.linkText( "Series Operadas" ), DriverW,30,5);
}


public WebElement getTable()
{ return BMV.fluentWait( By.id("formaSeriesOperadas:table" ),DriverW,30,5);
}

public WebElement getCotizacion()
{return BMV.fluentWait( By.name("cadenaCotizacion"),DriverW,30,5); }


public WebElement getCotizacionButton()
{return BMV.fluentWait( 
		//By.xpath("//img[contains(@src,'/TCSFramework/images/moredetails.gif')]")
		By.name("datosBusquedaCot")
		,DriverW,30,5);	
}

public WebElement getCot()
{return BMV.fluentWait(
	By.xpath("//img[contains(@src,'/img-bmv/WB3/link_menu_cotizaciones.gif')]")
	///img-bmv/WB3/link_menu_cotizaciones.gif
	,DriverW,30,5);
}

}
