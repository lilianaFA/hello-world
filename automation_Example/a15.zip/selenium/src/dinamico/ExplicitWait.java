package dinamico;

import java.util.Set;
import java.util.Vector;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import bmv.objetos.Busca;
import bmv.tareas.TareaInicio;
import bmv.util.EmisorBean;
import bmv.util.EmisorDAO;
import bmv.util.General;

public class ExplicitWait {

	public ExplicitWait() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{ General g = new General();	 
	  EmisorDAO ed = new EmisorDAO(); 
	  Vector<EmisorBean>  ve =ed.archivo("C:/wrk/juno/selenium/src/bmv/util/Emisor.txt");		  
	  
	  WebDriver  driver = g.Firefox();
	  driver.manage().timeouts().pageLoadTimeout(5, TimeUnit.SECONDS);
	  
	  TareaInicio tar = new TareaInicio(driver);	
			 tar.LaunchBMV();
			 tar.GoSeriesOperadas();
			 tar.cotiza("GBM");
			 
	  String ventana= driver.getWindowHandle();
	  Set<String> listav = driver.getWindowHandles();
	  for(String sw : listav)
		  {System.out.println(""+sw.toString());
		   if (!ventana.equals(sw))
		        { driver.switchTo().window(sw) ;
		        }		
		  }
		     
	  Busca load= PageFactory.initElements(driver, Busca.class);
	  
	  //explicit wait
	  
	  WebElement clv = (new WebDriverWait(driver, 10))
			  .until(ExpectedConditions.presenceOfElementLocated
					  (By.name("tab1:formaListaEmisoras:letraActual")));
	  
	  WebDriverWait wait = new WebDriverWait(driver, 10);
	  WebElement element = wait.until
			  (ExpectedConditions.elementToBeClickable
					  (By.name("tab1:formaListaEmisoras:letraActual")));


	  
	  
	  clv.clear();
	  clv.sendKeys("AMXL");	     

		 for (int i = 0; i<ve.size(); i++)
				{	String a = ve.elementAt(i).getEmisorBolsa().toString();
					//System.out.println(""+a);
					//bus.SociedadesInversion(a);
					load.SociedadesInversion(a);				
				}	     
			 //driver.close();	
		}


	}


