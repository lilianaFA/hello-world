package dinamico;

public class WicketLlibraryDotCom 
{

	public final String wicketURL="http://www.wicket-library.com/wicket-examples/index.html";
	
	public WicketLlibraryDotCom() 
	{
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
