package dinamico;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import bmv.util.General;

public class Modal {

	public Modal() 
	{ popup();
		// TODO Auto-generated constructor stub
	}

	
	public void popup()
	{ 
	  
	}
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{General g = new General();	
	  String url ="	http://www.ajaxshake.com/es/JS/12641/popup.html";
	  WebDriver  driver = g.Firefox();
	  Actions actions = new Actions(driver);
	  
		/*
	  driver.get(url);
	  driver.manage().timeouts().pageLoadTimeout(55, TimeUnit.SECONDS);
	  //Actions actions = new Actions(driver);
	  
	  WebElement pop=  g.fluentWait(By.xpath("//img[contains(@src,'public/resources/images/ajax-loader.gif')]"),driver,30,5);
	  WebElement next= g.fluentWait(By.id("cboxPrevious"),driver,30,5);
	  WebElement prev= g.fluentWait(By.id("cboxNext"),driver,30,5);  
	  WebElement close= g.fluentWait(By.id("cboxClose"),driver,30,5);
	  
	  WebElement twit=g.fluentWait(By.xpath
			  ("//a[contains(@href,'http://www.ajaxshake.com/demo/ES/620/c550d073/mostrar-en-un-popup-los-ultimos-tweets-usando-jquery-latest-tweets-tooltip-with-jquery.html')]"), 
			  driver, 30, 5);
	  */
	  
	  //actions.moveToElement(pop);
	  //twit.click();
	  //pop.click();
			  // no sirve, elemento no visible, se requiere una validacion
	  /*
	  if (next.isDisplayed() && next.isEnabled()) 
	  {next.click();
	  prev.click();
	  next.click();
	  prev.click();
	  close.click();}
	  */
	  
	  
	  //cambiar de ventana
	  
	  
	  String url2 ="http://simplemodal.plasm.it";
	  driver.get(url2);
	  driver.manage().timeouts().pageLoadTimeout(25, TimeUnit.SECONDS);
	  
	  WebElement modal1=  g.fluentWait(By.xpath("//img[contains(@src,'/application/assets/images/example-1.jpg')]")
			  ,driver,30,5);
	  
	  WebElement modalhe=  g.fluentWait(By.xpath("//img[contains(@src,'/application/assets/images/example-8.jpg')]")
			  ,driver,30,5);
	  
	  WebElement der;
	  WebElement izq;
	  WebDriverWait wait = new WebDriverWait(driver, 10);
	  
	  //WebElement cierra= driver.findElement(By.xpath("//a[contains(@title,'Close')]"));
	  
	  if (modal1.isDisplayed())
	  {System.out.println(" kl");
		  modal1.click();
		  
		  
		  WebElement element = wait.until
				  (ExpectedConditions.elementToBeClickable
						  (By.xpath("//a[contains(@title,'Close')]")));
		  element.click();
		  //cierra.click();
	  }
	  
	  modalhe.click();
	  izq=wait.until
			  (ExpectedConditions.elementToBeClickable
					  (By.xpath("//div[contains(@class,'simple-modal-footer align-left')]")));
	                  // (By.xpath("//div[contains(@class,'simple-modal-footer align-right')]")));
	  
	  if (izq.isDisplayed())
	  {
		  System.out.println(" DISP " +izq.isDisplayed() + " ENA "+ izq.isEnabled() +" SEL "+ izq.isSelected() 
				  +" TEXT " + izq.getText()+ " TAG  "+izq.getTagName()+"   TS "+ izq.toString()
				  );
		  izq.click();  
		  System.out.println("ya click  ");
		  
		  der=wait.until
				  (ExpectedConditions.elementToBeClickable
						  (By.xpath("//div[contains(@class,'simple-modal-footer align-right')]")));
		  
		  
		  der.click();
		  System.out.println("ya click 2 ");
	  }
	  //
	  
	  /*
	  der=wait.until
			  (ExpectedConditions.elementToBeClickable
					  (By.xpath("//div[contains(@class,'simple-modal-footer align-right')]")));
	  der.click();
	  */
	  
	  //cargar
	  //g.fluentWait(By.xpath("//a[contains(@title,'Close')]"),  driver, 30, 5); 
	 
	  // Alert alert = driver.switchTo().alert();
	   //System.out.print(""+alert.getText());
	   
	}

}
