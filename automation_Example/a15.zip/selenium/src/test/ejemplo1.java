package test;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
/*
import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.google.common.base.Function;
import com.thoughtworks.selenium.Selenium;
*/

import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import junit.framework.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.ie.*;
import org.openqa.selenium.WebDriver;

import com.google.common.base.Function;


public class ejemplo1 
{
	private  WebDriver driver2; //=new InternetExplorerDriver();   
	                          // = new HtmlUnitDriver();
	
	
	  public void startDriver() {
	      //  driver = new HtmlUnitDriver();
	    }
	  
	  public void stopDriver() {
	        driver2.close();
	    }
	  
	  
	  
	public ejemplo1() 
	{startDriver();
	
	
	//HtmlUnitDriver driver = new HtmlUnitDriver(BrowserVersion.getDefault());
	//driver.setJavascriptEnabled(true);
	FirefoxDriver driver2  = new FirefoxDriver();
	
	//File file = new File("C:/eclipse-jee-juno-SR2/jar/IEDriverServer.exe");
	//System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
	//WebDriver driver = new InternetExplorerDriver();
	
		  driver2.get("http://www.google.com.mx");

		  
		  
		  /*
		   <form id=gbqf name=gbqf method=get action="/search" onsubmit="gbar.logger.il(31);">
               <fieldset class=gbxx><legend class=gbxx>Campos ocultos</legend>
    			<div id=gbqffd><input type=hidden name="output" value="search">
        			<input type=hidden name="sclient" value="psy-ab">
     			</div>
  				</fieldset>
  				
  				<fieldset class=gbqff id=gbqff><legend class=gbxx></legend>
   					<div id=gbfwa class="gbqfwa ">
      					<div id=gbqfqw class=gbqfqw>
        					<div id=gbqfqwb class=gbqfqwc>
             					<input id=gbqfq class=gbqfif name=q 
               					type=text autocomplete=off value="" >
        					</div>
      					</div>
   					</div>
  				</fieldset>
  				
  			<div id=gbqfbw>
   				<button id=gbqfb aria-label="Buscar con Google" class=gbqfb name=btnG>
   				 <span class=gbqfi></span></button>
  			</div>
  			<div id=gbqfbwa class=jsb>
   					<button id=gbqfba aria-label="Buscar con Google" name=btnK class=gbqfba>
      				<span id=gbqfsa>Buscar con Google</span>
   					</button>

   			<button id=gbqfbb aria-label="Me siento con suerte" name=btnI class=gbqfba 
          			onclick="if(this.form.q.value)this.checked=1;else window.top.location='/doodles/'">
     				<span id=gbqfsb>Me siento con suerte</span>
     		</button></div></form></div>
  </div>


            <span class=gbts>B�squeda</span></a></li>
            <li class=gbt>
             <a onclick=gbar.qs(this);gbar.logger.il(1,{t:2}); 
              class=gbzt id=gb_2 href="http://www.google.com.mx/imghp?hl=es-419&tab=wi">
              
              <span class=gbtb2></span>
              <span class=gbts>Im�genes</span></a>
              
              </li><li class=gbt>
                <a onclick=gbar.qs(this);gbar.logger.il(1,{t:78}); 
                 class=gbzt id=gb_78 href="https://play.google.com/?hl=es-419&tab=w8">
                 <span class=gbtb2></span><span class=gbts>Play</span></a>
		   */
		  
		  
		  
	        // por nombre, el primer match
		    //<input id=gbqfq class=gbqfif name=q type=text autocomplete=off value="" 
		 	WebElement 
		 	/*
		 	campo_busqueda = driver.
		 			findElementByXPath("//input[@type='text']");
		    		//findElement(By.name("q"));
		 			 	
	        // buscar
	        campo_busqueda.sendKeys("Selenium");
	    
	        */
	         campo_busqueda = 
	        		fluentWait2(By.xpath("//input[@type='text']"),driver2); 
	        				//findElementByXPath("//input[@type='text']") );
	        	/*	driver.
		 			findElementByXPath("//input[@type='text']");
	        */
	        		campo_busqueda.sendKeys("Selenium");
	        		
	        // Now submit the form. WebDriver will find the form for us from the element
	        campo_busqueda.submit();

	        // Check the title of the page
	        System.out.println("Page title is: " + driver2.getTitle());

		  driver2.quit();
       //stopDriver(); 
	}
	
	
	public WebElement fluentWait2(final By locator, WebDriver driver) {
	    Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
	            .withTimeout(30, TimeUnit.SECONDS)
	            .pollingEvery(5, TimeUnit.SECONDS)
	            .ignoring(NoSuchElementException.class);

	    WebElement foo = wait.until(new Function<WebDriver, WebElement>() {
	        public WebElement apply(WebDriver driver) {
	            return driver.findElement(locator);
	        }
	    });

	    return  foo;
	}

	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new ejemplo1();
	 

	}

}
