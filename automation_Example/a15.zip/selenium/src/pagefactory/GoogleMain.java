package pagefactory;

import org.openqa.selenium.WebElement;

public class GoogleMain 
{
	private WebElement q;  //buscar
	
	public  final String gmx= "http://www.google.com.mx";
	public  final String gusa= "http://www.google.com";
	public  final String gfr= "http://www.google.com.fr";
	
	
	
	public void buscar(String Cadena)
	{q.sendKeys(Cadena);
      q.submit();
	}
	
	
	public String xpathbuilder(String tipo, String id, String valor )
	{
		System.out.println("");
		String a= "//"+tipo+"["+"@"+id+"="+"'"+valor+"'"+"]";
		System.out.println("");
		
		return "//"+tipo+"["+"@"+id+"="+"'"+valor+"'"+"]"  ;
		
		
		//findElementByXPath("//input[@type='text']");//
		
	}
	
	
	
	public GoogleMain() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
