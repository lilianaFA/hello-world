package pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.support.PageFactory;

import Util.Launcher;

public class Ejemplo2 {

	private static String Log ="";
	private final static String NL = System.getProperty ("line.separator");
	
	public Ejemplo2() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	try{	
		Launcher l = new Launcher();
		Log+=NL+"lanza";
		 GoogleMain gm= new GoogleMain();
		 Log+=NL+"inicia gm";
		 WebDriver driver = l.Firefox();
		 Log+=NL+" inicia driver";	
		 driver.get(gm.gfr);
		 Log+=NL+" lanza gg mx";	
		 GoogleMain page = PageFactory.initElements(driver, GoogleMain.class);
		 Log+=NL+" page factory";
		 page.buscar("Mexico");
		 Log+=NL+" busca";	 
		 driver.quit();
		 Log+=NL+"salir";	
		 }
	catch (Exception e)
	     { Log+=NL+"exceptioin";
		   Log+=NL+" "+ e.getMessage().toString() ;
		   e.printStackTrace() ;
	     }
	System.out.println("" + Log);
	}
	
	public void testcase1()
	{Launcher l = new Launcher();
	 GoogleMain gm= new GoogleMain();
		WebDriver driver = l.Firefox();
		driver.get(gm.gmx);
		 GoogleMain page = PageFactory.initElements(driver, GoogleMain.class);
		 page.buscar("Mexico");
		 driver.quit();
		 
	}

}
