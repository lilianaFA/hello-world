package bmv.objetos;

import org.openqa.selenium.By;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.WebElement;


public class Busca {

	@FindBy (how = How.NAME,using="tab1:formaListaEmisoras:letraActual")
	@CacheLookup
	private WebElement Clave;
	
	@FindBy (how = How.NAME,using="tab1:formaListaEmisoras:letraActual")
	@CacheLookup
	private WebElement TipoEmisora;
	
	@FindBy (how = How.NAME,using="tab1:formaListaEmisoras:sectorActualKeyl")
	@CacheLookup
	private WebElement Sector;
	
	@FindBy (how = How.NAME,using="tab1:formaListaEmisoras:botonSubmit")
	@CacheLookup
	private WebElement BuscarValor;
	
	@FindBy (how = How.NAME,using="_id3.2")
	@CacheLookup
	private WebElement SociedadesInversion;
	
	
	@FindBy (how = How.NAME,using="tab3:formaListaSociedadesInversion:selector")
	@CacheLookup
	private WebElement PorOperadora;
	
	@FindBy (how = How.NAME,using="formaListaSociedadesInversion:selector")
	@CacheLookup
	private WebElement PorSociedad;	
	
	@FindBy (how = How.NAME,using="tab3:formaListaSociedadesInversion:cadenaBusquedaOperadora")
	@CacheLookup
	private WebElement 	BuscarTextfield;
	
	@FindBy (how = How.NAME,using="tab3:formaListaSociedadesInversion:botonSubmitSociedad")
	@CacheLookup
	private WebElement 	BuscarButton;	
	
	//este es de otra pagina
	@FindBy (how = How.XPATH,using="//img[contains(@src,'/img-bmv/WB3/link_menu_cotizaciones.gif')]")
	@CacheLookup
	private WebElement 	Cotizar;
	
	
	public Busca() {
		// TODO Auto-generated constructor stub
	}

	
	public void SociedadesInversion(String sociedad)
	{	SociedadesInversion.click();
	     //PorSociedad.click();
	     BuscarTextfield.clear();
	     BuscarTextfield.sendKeys(sociedad);
	     BuscarButton.click();
	}
	
	public void emisor(String g)
	{Clave.clear(); Clave.sendKeys(g); }
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
