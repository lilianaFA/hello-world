package bmv.objetos;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import bmv.util.*;

public class BuscaEmisoa 
{  General BMV = new General();
	WebDriver DriverW;

	public BuscaEmisoa(WebDriver driver) 
	{ DriverW=driver ;	}
	
	public WebElement getClave()
	{return BMV.fluentWait(By.name("tab1:formaListaEmisoras:letraActual")
    // By.xpath("//input[@type='text']")
			             //tab1:formaListaEmisoras:letraActual
			               //By.xpath("//input[@id='tab1:formaListaEmisoras:letraActual']" )
			,DriverW,30,5);	
	}
	
	public WebElement getTipoEmisora()
	{return BMV.fluentWait(By.name("tab1:formaListaEmisoras:tipoActual")
			,DriverW,30,5);	
	}
	
	
	public WebElement getSector()
	{return BMV.fluentWait(By.name("tab1:formaListaEmisoras:sectorActualKeyl")
			,DriverW,30,5);	
	}

	
	public WebElement getBuscarValor()
	{return BMV.fluentWait(By.name("tab1:formaListaEmisoras:botonSubmit")
			,DriverW,30,5);	
	}
	
	public WebElement getSociedadesInversion()
	{
		return BMV.fluentWait( //By.xpath("input[@value='Sociedades de inversi&oacute;n'" )
				               //By.id("tab3:_id123_headerCell")
				               By.name("_id3.2")
				               //By.name("tab3:formaListaSociedadesInversion:cadenaBusquedaOperadora")
				,DriverW,30,5);
	}
	
	public WebElement getPorOperadora()
	{
		return BMV.fluentWait( By.name("tab3:formaListaSociedadesInversion:selector")
				,DriverW,30,5);
	}	
	

	public WebElement getPorSociedad()
	{
		return BMV.fluentWait( By.name("tab3:formaListaSociedadesInversion:selector")
				,DriverW,30,5);
	}
	
	
	public WebElement getBuscarTextfield()
	{
		return BMV.fluentWait( By.name("tab3:formaListaSociedadesInversion:cadenaBusquedaOperadora")
				,DriverW,30,5);
	}
	
	public WebElement getBuscarButton()
	{
		return BMV.fluentWait( By.name("tab3:formaListaSociedadesInversion:botonSubmitSociedad")
				,DriverW,30,5);
	}
}
