package bmv.tareas;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import bmv.objetos.*;

public class TareaInicio 
{
	WebDriver DriverT;
	Inicio Getobj; 
	
	public String Log = "" ;
	
	public TareaInicio(WebDriver a) 
	{ DriverT=a;
	  Getobj = new Inicio(DriverT);
	  
		
	}

	public void LaunchBMV()
	{ DriverT.get(Getobj.bmv );
	}

	public void GoAcercadeBolsa()
	{ Getobj.getTabAcercadeBolsa().click();		
	}
	
	public void GoSeriesOperadas()
	{
		Getobj.getLnMercadoC().click();
		Getobj.getLnSeriesO().click();
		
	}
	
	
	public void cotiza(String texto)
	{Getobj.getCotizacion().clear();
	 Getobj.getCotizacion().sendKeys(texto);
	// Getobj.getCotizacionButton().submit();
	 Getobj.getCot().click();
	}
	
	public void Tabla()
	{WebElement table =Getobj.getTable();
		
	List<WebElement> tablas=table.findElements(By.xpath("id('formaSeriesOperadas:table')/tbody/tr"));
	
	int i, j;
    i=1;
    String aux="";
    for(WebElement trElement : tablas)
    {aux="";
        List<WebElement> Lista_elem=trElement.findElements(By.xpath("td"));
                j=1;
        for(WebElement tdElement : Lista_elem)
        {     //poner 0 si PPP esta vacio
        	 if (j==5 && tdElement.getText().length()==0 )
        	  {aux+= "0"+ " " ; }
        	 else
               aux+= tdElement.getText()+ " " ;
           
            
            j++;
        } System.out.println(aux );
        i++;
    }
		
	}
}
