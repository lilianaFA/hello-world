package bmv.tareas;

import org.openqa.selenium.WebDriver;
import bmv.objetos.*;

public class TareaBusca 
{   public String Log = "" ;
	WebDriver DriverT;
	BuscaEmisoa Be;
	
	public TareaBusca(WebDriver a) 
	{DriverT=a;
	 Be = new BuscaEmisoa(a);
		
	}

	public void Emisoas(String s)
	{Be.getClave().sendKeys(s);
		
	}
	
	public void SociedadesInversion(String sociedad)
	{	Be.getSociedadesInversion().click();
		Be.getPorSociedad();
		Be.getBuscarTextfield().clear();
		Be.getBuscarTextfield().sendKeys(sociedad);
		Be.getBuscarButton().click();
	}

}
