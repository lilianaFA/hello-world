package bmv.util;

public class EmisorBean 
{ private String emisorBolsa;

	public EmisorBean() {
		
	}

	public String getEmisorBolsa() {
		return emisorBolsa;
	}

	public void setEmisorBolsa(String emisorBolsa) {
		this.emisorBolsa = emisorBolsa;
	}



}
