package bmv.util;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.google.common.base.Function;

import javax.imageio.ImageIO;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;



import java.io.IOException;


import org.apache.commons.io.FileUtils;



/**
 * @author israel
 *
 */
/**
 * @author israel
 *
 */
/**
 * @author israel
 *
 */
public class General 
{	
	public enum Locators		{  id, name, xpath, classname, linktext, paritallinktext,  tagname };

	/**
	 * metodo generico para obtener un webelement
	 * Elementos:
	 * id, name, xpath, classname, linktext, paritallinktext,  tagname
	 * 
	 * @param locator locator
	 * @param elementob elemento a buscar
	 * @param driver instancira driver
	 * @return elemento
	 * @throws Exception
	 */
	 
	public WebElement getWebElement( Locators locator, String elementob, WebDriver driver ) throws Exception 
	 { By MiElemento;
	   switch ( locator ) 
	    {		
		 
		 case id:		{ MiElemento = By.id(elementob); break; }
		 case name:		{ MiElemento = By.name(elementob); break; }
		 case xpath:	{ MiElemento = By.xpath(elementob); break; }
		 case classname:{ MiElemento = By.className(elementob); break; }
		 case linktext:	{ MiElemento = By.linkText(elementob); break; }
		 case paritallinktext:{ MiElemento = By.partialLinkText(elementob); break; }
		 case tagname:	{ MiElemento = By.tagName(elementob); 		break; }
		 default:		{ throw new Exception("Elemento no conocido"); }
		}
	  
	   WebElement elemento = driver.findElement( MiElemento );	
	   return elemento;	
	 }


	public WebDriver HtmlDriver()
	{HtmlUnitDriver driver = new HtmlUnitDriver(BrowserVersion.getDefault());
	 driver.setJavascriptEnabled(true);
	 return driver;	
	}

	/**
	 * 
	 * @return instancia drieve firefox
	 */
	 public WebDriver Firefox( )
      {FirefoxDriver driver  = new FirefoxDriver();
       return driver;	
      }
	
	 /**
	  * 
	  * @return instancia driver IE
	  */
	 public WebDriver IE()
	 {File file = new File("C:/eclipse-jee-juno-SR2/jar/IEDriverServer.exe");
			System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
			WebDriver driver = new InternetExplorerDriver();
	 return driver;
	 }
	 
	 
	 /**
	  * 
	  * @param driverfile locacion donde se encuentra el driver para IE
	  * @return
	  */
	 public WebDriver IE(String driverfile)
	 {File file = new File(driverfile);
			System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
			WebDriver driver = new InternetExplorerDriver();
	 return driver;
	 } 
	 
	 
	 /**
	  * 
	  * @param locator locator
	  * @param driver web driver
	  * @param lapso  lapso max de espera en segundos
	  * @param polling intervaloentre cada intento en segundos
	  * @return
	  */
	 public WebElement fluentWait(final By locator, WebDriver driver, int lapso, int polling)  
	 {
		    Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
		            .withTimeout(lapso, TimeUnit.SECONDS)
		            .pollingEvery(polling, TimeUnit.SECONDS)
		            //.ignoring(NoSuchElementException.class)
		            ;
		    // ElementNotVisibleException.class
		    //NoAlertPresentException, NoSuchElementException, NoSuchFrameException, NoSuchWindowException

		    WebElement elemento = wait.until(new Function<WebDriver, WebElement>() {
		        public WebElement apply(WebDriver driver) {
		            return driver.findElement(locator);
		        }
		    });

		    return  elemento;
		}

	
	 public boolean Takepicture(String location,WebDriver driver )
	 {
	 
		 File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		// Now you can do whatever you need to do with it, for example copy somewhere
		try {
			FileUtils.copyFile(scrFile, new File("c:\\Temp\\"+location+".png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return true;
	 }
	 
}
