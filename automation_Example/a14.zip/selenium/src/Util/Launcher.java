package Util;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import com.gargoylesoftware.htmlunit.BrowserVersion;

public class Launcher 
{

	public Launcher() {
		// TODO Auto-generated constructor stub
	}
	
	
	public WebDriver HtmlDriver()
	{HtmlUnitDriver driver = new HtmlUnitDriver(BrowserVersion.getDefault());
	 driver.setJavascriptEnabled(true);
	 return driver;	
	}

	
	 public WebDriver Firefox( )
      {FirefoxDriver driver  = new FirefoxDriver();
       return driver;	
      }
	
	 public WebDriver IE()
	 {File file = new File("C:/eclipse-jee-juno-SR2/jar/IEDriverServer.exe");
			System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
			WebDriver driver = new InternetExplorerDriver();
	 return driver;
	 }
	
	
	
	
	

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
